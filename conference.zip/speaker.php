<?php 
	include('head.php');
	include('header.php');
	include('nav.php');
?>

<div class="col-lg-6 col-md-6 col-sm-6">
	<h3>Speakers/ Invitees</h3>
				<h3 class="main">Speakers</h3>
				<div class="table-responsive">
				<table class="table table-hover">
					<tbody>
												<!--speaker1-->
						<tr>
							<td rowspan="3">
								<a href="#" target="_blank"><img src="#" alt="#" class="img-responsive" /></a></td>
							<td style="width:249px; height:50px;"><b>Prof. S </b></td>
						</tr>
						<tr>      
						  <td style="height:25px;">Welcome &amp; Inaugural Address</td>
						</tr>
						<tr>      
						  <td style="height:25px;">Director,<br/>
						  	Indian Institute of Information Technology 
						  	Allahabad (IIITA)</td>
						</tr>
						<!--speaker1 finished-->
						<!--speaker1-->
						<tr>
							<td rowspan="3"><a href="#" target="_blank"><img src="" alt="Prof. J" class="img-responsive" /></a></td>
							<td style="width:249px; height:50px;"><b>Prof. Jonathan Corney</b></td>
						</tr>
						<tr>      
						  <td style="height:25px;">Topic:  Using Scottish home workers for Geometric Computation</td>
						</tr>
						<tr>      
						  <td style="height:25px;">Professor of Design and Manufacture,<br/>
						  	University of Strathclyde,<br/> 
						   	Glasgow (UK)</td>
						</tr>
						<!--speaker1 finished-->
						<!--speaker1-->
						<tr>
							<td rowspan="3"><a href="#" target="_blank"><img src="
							<td style="width:249px; height:50px;"><b>Prof. A</b></td>
						</tr>
						<tr>      
						  <td style="height:25px;">Topic: Optimizing 2D component nesting layouts with Rural Indian IT Service Centres</td>
						</tr>
						<tr>      
						  <td style="height:25px;">Professor of Computer Science and IT, 
						  	<br/>Indian Institute of Information Technology Allahabad (IIITA)
						  </td>
						</tr>
						<!--speaker1 finished-->
						<!--speaker1-->
						<tr>
							<td rowspan="3"><a href="#" target="_blank"><img src="images/venkat.jpg" alt="Dr Venkat Kumar" class="img-responsive"/></a></td>
							<td style="width:249px; height:50px;"><b>Dr Venkat Kumar</b></td>
						</tr>
						<tr>      
						  <td style="height:25px;">Topic: “Rural Shoring”: an 'operating template' that  is enabling rural Indian youth to deliver businessIT processes in 10 states</td>
						</tr>
						<tr>      
						  <td style="height:25px;">Chief Operating Officer, Executive Vice President, Rural Shores Ltd</td>
						</tr>
						<!--speaker1 finished-->
						<!--speaker1-->
						<tr>
							<td rowspan="3"><a href="#" target="_blank"><img src="images/jacki.jpg" alt="Dr Jacki O'Neill" class="img-responsive" /></a></td>
							<td style="width:249px; height:50px;"><b>Dr. Jacki O'Neill</b></td>
						</tr>
						<tr>      
						  <td style="height:25px;">Topic: “What do we know about IndianCrowdworkers?” Qualitative studies into crowdsourcing and crowdworkers that identify the benefits and barriers.</td>
						</tr>
						<tr>      
						  <td style="height:25px;">Senior Researcher, <br/>Microsoft Research India, <br/>Bengaluru</td>
						</tr>
						<!--speaker1 finished-->
						<!--speaker1-->
						<tr>
							<td rowspan="3"><a href="#" target="_blank"><img src="images/ashok.jpg" alt="Prof. Ashok Jhunjhunwala" class="img-responsive" /></a></td>
							<td style="width:249px; height:50px;"><b>Prof. A</b></td>
						</tr>
						<tr>      
						  <td style="height:25px;">Topic: DesiCrew: Take Jobs to the People instead of People to Jobs</td>
						</tr>
						<tr>      
						  <td style="height:25px;">Department of Electrical Engineering, <br/>Indian Institute of Technology Madras, Chennai</td>
						</tr>
						<!--speaker1 finished-->
					</tbody>
				</table>
				<h3 class="main">Invitees (Talk during Panel Discussion)</h3><p>(to be updated soon...)</p>
			</div>
				<hr>
			</div>
<?php 
include('right_bar.php');
include('footer.php');
?>
