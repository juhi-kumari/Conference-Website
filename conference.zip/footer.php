<footer class="row">
	             <p><center> &copy; Copyright 2015 IIIT Allahabad | Developed by Juhi Kumari | Department of Information Technology, IIIT-A &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</center></p>
	    </footer>
	</div>
	<!-- javascript -->
		<script src="http://code.jquery.com/jquery-latest.min.js"></script>
	    <script src="js/bootstrap.min.js"></script>
</body>
</html>
