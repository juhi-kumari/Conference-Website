<body>
	<div class="container">
		<!--header-->
		<div class="jumbotron">
			<div class="col-sm-2 col-md-2">
				<a href="#" target="_blank"><img src="images/iiit.jpg" style="height:150px; width:200px;opacity: 1;" class="img-responsive"></a>

			</div>
			<div  class="col-sm-8 col-md-8">
				<center>
					<a href="#" target="_blank"><img src="images/tiar1.png"></a>
					<h4>Workshop on</h4>
					<h3 style="border:2px solid white; color:#E5E9E9"><b>
						Creating Sustainable Rural Employment through Industrial Process Outsourcing
						</b></h3>
					
					<h4 style="padding-top:-1px;">(Supported by </h4>
					<h5 style="color:yellow"><b>11<sup>th</sup> July 2015 (9am - 2pm)</b></h5>
				</center>
			</div>
			<div  class="col-sm-2 col-md-2">
				<a href="#" target="_blank"><img src="images/university.png"  style="height:150px; width:200px;" class="img-responsive"></a>
				
			</div>
		</div>
		<!--header finished-->
