<?php 
	include('head.php');
	include('header.php');
	include('nav.php');
?>
<div class="col-lg-6">
				<div id="myCarousel" class="carousel slide" data-ride="carousel">
					    <!-- Indicators -->
					<ol class="carousel-indicators">
					    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
					    <li data-target="#myCarousel" data-slide-to="1"></li>
					    <li data-target="#myCarousel" data-slide-to="2"></li>
					    <li data-target="#myCarousel" data-slide-to="3"></li>
					    <li data-target="#myCarousel" data-slide-to="4"></li>
					</ol>

				    <!-- Wrapper for slides -->
				    <div class="carousel-inner" role="listbox">

				      <div class="item active">
				        <img src="images/temp.png" alt="" style="width: 500px; height: 300px;">
				        <div class="carousel-caption">
				          
				          <p style="opacity:0.4; background-color:black;"></p>
				        </div>
				      </div>

				      <div class="item">
				        <img src="images/iiita1.jpg" alt="iiita images" class="img-responsive" style="width: 500px; height: 300px;">
				        <div class="carousel-caption">
				          
				          <p>IIITA has a great campus life with state of the art facilities and infrastructure.</p>
				        </div>
				      </div>
				    
				      <div class="item">
				        <img src="images/iiita2.jpg" alt="iiita images" class="img-responsive" style="width: 500px; height: 300px;">
				        <div class="carousel-caption">
				          
				          <p>Arial view of IIITA</p>
				        </div>
				      </div>

				      <div class="item">
				        <img style="width: 500px; height: 300px;" src="images/university.jpg" alt="University of Strathclyde, Scotland, UK" class="img-responsive">
				        <div class="carousel-caption">
				          
				          <p>University of Strathclyde, Scotland, UK</p>
				        </div>
				      </div>
				      <div class="item">
				        <img style="width: 500px; height: 300px;" src="images/university2.jpg" alt="University of Strathclyde, Scotland, UK" class="img-responsive">
				        <div class="carousel-caption">
				          
				          <p>Technology and Innovation Centre Strathclyde</p>
				        </div>
				      </div>
				  
				    </div>

				    <!-- Left and right controls -->
				    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
				      <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
				      <span class="sr-only">Previous</span>
				    </a>
				    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
				      <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
				      <span class="sr-only">Next</span>
				    </a>
				  </div>
						
			<h3>Introduction</h3>
			<p>This special workshop session will focus on the technologies, business and opportunities associated with micro-outsourcing of Industrial work to ITCentres and/ or individual workers in rural locations.The ability of modern information technology to dramatically reduce the costs of communication and data transfer is creating new opportunities for economic activities in rural areas. This workshop will explore: the emerging infrastructure (e.g. Rural IT and BPO centres and Crowdsouring platforms); research into novel forms of industrial work (e.g. CAD/CAM optimisation) that exploit human computational abilities and understand the skills and motivations of the people who form this new online labour force. Speakers from business and academia will share their work and experiences of this emerging area both in India and elsewhere.</p>
			<hr>	
			</div>
<?php 
include('right_bar.php');
include('footer.php');
?>
