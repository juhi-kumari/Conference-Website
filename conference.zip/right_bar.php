<div class="col-lg-3 col-md-4 col-sm-4">
				<div class="sponser">
					<h3>Sponsers</h3>
					<div id="myCarousel" class="carousel slide" data-ride="carousel">
					<div class="carousel-inner" role="listbox">

				      <div class="item active">
				        <a href="https://www.epsrc.ac.uk/" target="_blank"><img src="images/EPSRC.jpg" alt="EPSRC" style="height: 150px; width:200px" class="img-responsive img-thumbnail"></a>
				        
				      </div>
				      <div class="item">
				        <a href="http://www.scienceandsociety-dst.org/new.htm" target="_blank"><img src="images/dst.png" alt="DST" class="img-responsive img-thumbnail" style="height: 150px; width:200px"></a>
				        
				      </div>

				    </div>
					</div>
				</div>
				
				<div style="padding-top:0px;">
				<h3>Latest News</h3>
				<div id='sidebar-top'>
					
				  <p>
					<!--for scrolling updates-->
					
					<style type="text/css">#pscroller1{height:150px; padding:5px; background-color:White; color:black;}</style>
				
					<script type="text/javascript">
						var pausecontent=new Array()
					
					
					pausecontent[0]=' <div class="not"><span class="glyphicon glyphicon-forward"></span><a href="reg.php">Registration Open</a> <br/><span class="glyphicon glyphicon-forward"></span><a href="sponsers.php">Call for Sponsers</a></div>'
					pausecontent[1]='';
					</script>
					<script type="text/javascript" src="js/java.js"></script> 
						
						
					<script type="text/javascript">
						//new pausescroller(name_of_message_array, CSS_ID, CSS_classname, pause_in_miliseconds)
						new pausescroller(pausecontent, "pscroller1", "someclass", 2)
						document.write
					</script>
					</p>
					
				
				</div>
				<hr>
				
			
			<h3>Important Dates</h3>
			<UL>
				<li>Date of the event</li>
				<p>11<sup>th</sup> July, 2015</p>
				<li>Early Bird Registration</li>
				<p>15<sup>th</sup> June, 2015</p>
			</UL>	
			<hr>
		</div>
	</div>
</div>