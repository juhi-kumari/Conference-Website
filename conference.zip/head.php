<head>
    <meta charset="utf-8">
   <!-- <img src="images/iiita.png" />-->
    <title>BURD Workshop 2015</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!--<link href="css/bootstrap.css" rel="stylesheet">-->
    <link href="css/style.css" rel="stylesheet">
    <script src="js/respond.js"></script>
    <script src="js/jquery1.js"></script>
    <link rel="shortcut icon" href="images/iiita.png" type="image/x-icon"/>
</head>
