<?php 
	include('head.php');
	include('header.php');
	include('nav.php');
?>

			<div class="col-lg-6">
				<h3 class="main">Contact Us</h3>
				<ul>
					<li><b>Prof. ABCD</b>
					<p> Professor of Computer Science and IT, 
						<br/>
						Email: b@gmail.com, a@gmail.com
						</p></li>
					<li><b>Prof. PQRS</b><br/>
						<p>Professor of Design and Manufacture,<br/>
						University</br>
						
						Email: J@gmail.com 
					</p>
					</li>
				</ul>
			</div>
<?php 
include('right_bar.php');
include('footer.php');
?>
