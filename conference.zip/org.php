<?php 
	include('head.php');
	include('header.php');
	include('nav.php');
?>
<div class="col-lg-6">
			<h3>Organisers</h3>
			<a href="#"><h3 class="main">Indian Institute of Information Technology</h3></a>
			<p> The Indian Institute of Information Technology was 
				established in 1999, as a center of excellence in Information Technology 
				and allied areas. The institute was conferred the "Deemed University" 
				status by Govt. of India in the year 2000.
				<br/><br/>
				The Institute has been conceived with the ambitious objectives of developing professional
				 expertise and skilled manpower in Information Technology (IT) and related areas.
				 As an apex nucleating institute in the area of IT, the establishment of IIIT, is a major 
				 step of Govt. of India towards strengthening the indigenous capability necessary for 
				 exploiting profitably and harnessing multi-dimensional facets of IT at all levels, 
				 and attaining expertise to enable the country to emerge as a leading player in the global 
				 arena. IIIT has consistently been ranked as among the top technical schools in the country.
				 It was given the 8th overall rank in India by India Today.
			</p>
			<hr>
			<a href="#"><h3 class="main"><!--University-->University</h3></a>
			<p>The University is a Scottish public research university located in Glasgow,
			 United Kingdom. 
			 It is Glasgow's second university by age, 
			 being founded in 1796 as the Andersonian Institute, and receiving its Royal 
			 Charter in 1964 as the UK's first technological university. It takes its name 
			 from the historic Kingdom of Strathclyde.
			 <br/><br/>
			The University is Scotland's third largest university by number 
			of students, with students and staff from over 100 countries. The institution was 
			awarded University of the Year 2012 and Entrepreneurial University of the year 
			2013 by Times Higher Education.
			Applications for a place into many of the courses in the university is competitive
			 and successful entrants in 2015 had an average of 473 UCAS points. This equates 
			 to successful applicants to Strathclyde have the 12th highest average score, 
			compared to other UK higher education institutions</p><hr>
			</div>
<?php 
include('right_bar.php');
include('footer.php');
?>
