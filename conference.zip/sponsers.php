<?php 
	include('head.php');
	include('header.php');
	include('nav.php');
?>
<div class="col-lg-6">
				<h3>Call for Sponsers</h3>
				<p>The half day workshop is attracting eminent delegates from across the globe. 
					Approximetly 50 - 70 delegates/ participants are expected to attend the workshop.
					<br/>
					It is a good opportunity for brands to make their presence felt by becoming a 
					sponsor for the event.
					<br/>
					The workshop team has identified some ways in which a sponsoring agency can mark their presence</p>
					<br/>
					<table class="table table-hover">
						<thead>
							<tr>
								<th>Name of sponsorship</th>
								<th>Amount in INR</th>
								<th>No. of Sponsors</th>
								<th>Benefits to Sponsers</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>Tea Break</td>
								<td>INR 15,000</td>
								<td>1</td>
								<td>Display of brand logo on workshop website, banners, brochures, 
									delegate kit etc. 2 free registration.</td>
							</tr>
							<tr>
								<td>Lunch for Guests</td>
								<td>INR 20,000</td>
								<td>1</td>
								<td>Display of brand logo on workshop website, banners, brochures, 
									delegate kit etc. 3 free registration.</td>
							</tr>
							<tr>
								<td>Hospitality</td>
								<td>INR 75,000</td>
								<td>2</td>
								<td>Display of brand logo on workshop website, banners, brochures, 
									delegate kit etc. Video display of company promotion during tea-break. 5 free registration.</td>
							</tr>
							<tr>
								<td>Transportation</td>
								<td>INR 20,000</td>
								<td>1</td>
								<td>Display of brand logo on workshop website, banners, brochures, 
									delegate kit etc. 3 free registration.</td>
							</tr>
							<tr>
								<td>Delegate Kit/ stationary</td>
								<td>INR 20,000</td>
								<td>1</td>
								<td>Display of brand logo on workshop website, banners, brochures, 
									delegate kit etc. 3 free registration.</td>
							</tr>
						</tbody>
					</table>
					<hr>
					<h3 class="main">Payment Mode</h3>
					<p>Payment may be made as per the information given in the <a href="reg.php#payment">registration page</a>.
					</p>
					<h3 class="main">Contact</h3><p>
					
						<br/>
						Email: b@gmail.com 
						</p>
				<hr>
			</div>
<?php 
include('right_bar.php');
include('footer.php');
?>
