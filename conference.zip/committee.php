<?php 
	include('head.php');
	include('header.php');
	include('nav.php');
?>
<div class="col-lg-7 col-md-6 col-sm-6">
	<div class="table-responsive">
	<h3> Organising Committee</h3>
	<table class="table table-hover" style="width:; height:;">
		<thead>
			<th>Member's Name</th>
			<th>Address</th>
		</thead>
		<tbody>
			<tr>
				<td>Prof. J</td>
				<td>University</td>
			</tr>
			<tr>
				<td>Prof. A</td>
				<td>Indian Institute of Information Technology</td>
			</tr>
			<tr>
				<td>Dr G</td>
				<td>University</td>
			</tr>
			<tr>
				<td>Dr P</td>
				<td>University</td>
			</tr>
			<tr>
				<td>Mr. N</td>
				<td>Indian Institute of Information Technology</td>
			</tr>
			<tr>
				<td>Mr. C</td>
				<td>Indian Institute of Information Technology</td>
			</tr>
			<tr>
				<td>Mr. P</td>
				<td>Indian Institute of Information Technology</td>
			</tr>
			<tr>
				<td>Mr. R</td>
				<td>Indian Institute of Information Technology</td>
			</tr>
			
		</tbody>
	</table>
</div>
</div>
<?php 
include('right_bar.php');
include('footer.php');
?>
