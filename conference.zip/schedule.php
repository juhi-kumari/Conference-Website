<?php 
	include('head.php');
	include('header.php');
	include('nav.php');
?>
<div class="col-lg-6">
				<h3 class="main">Schedule</h3>
				<p>Download the schedule from <a href="#">here</a></p>
				
			</div>
<?php 
include('right_bar.php');
include('footer.php');
?>