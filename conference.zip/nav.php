<div class="row">
			<div class="col-sm-2 col-md-2 col-lg-2">
				<ul class="nav nav-pills nav-stacked">
					<li><a href="index.php">Home</a></li>
					<li><a href="org.php">Organisers</a></li>
					<li><a href="speaker.php">Speakers</a></li>

					<li><a href="reg.php">Registration</a></li>
					<li><a href="schedule.php">Schedule</a></li>
					<li><a href="sponsers.php">Call for Sponsers</a></li>
					<li><a href="venue.php">Venue</a></li>
					<li><a href="contact.php">Contact</a></li>
					<li><a href="committee.php">Org. Committee</a></li>
					
					
				</ul>
			</div>
