<?php 
	include('head.php');
	include('header.php');
	include('nav.php');
?>
<div class="col-lg-6">
<h3 class="main">Venue</h3>
<p>India</p>
<p> Map will be uploded soon...
</div>

<?php 
include('right_bar.php');
include('footer.php');
?>
